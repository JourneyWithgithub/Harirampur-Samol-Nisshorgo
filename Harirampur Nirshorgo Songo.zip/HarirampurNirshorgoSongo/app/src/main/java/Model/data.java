package Model;

import java.io.Serializable;

public class data implements Serializable {

    String applicantName;
    String fatherName;
    String motherName;
    String presentAddress;
    String permanentAddress;
    String upzillaName;
    String unionName;
    String nidNumber;
    String bloodGroup;
    String occupation;
    String dob;
    String mobileNumber;
    String educationQualification;
    String nationality;
    String email;
    String id;

    // New fields
    boolean approved;
    boolean deleted;

    public data() {

    }

    public data(String applicantName, String fatherName, String motherName, String presentAddress, String permanentAddress, String upzillaName, String unionName, String nidNumber, String bloodGroup, String occupation, String dob, String mobileNumber, String educationQualification, String nationality, String email, String id, boolean approved, boolean deleted) {
        this.applicantName = applicantName;
        this.fatherName = fatherName;
        this.motherName = motherName;
        this.presentAddress = presentAddress;
        this.permanentAddress = permanentAddress;
        this.upzillaName = upzillaName;
        this.unionName = unionName;
        this.nidNumber = nidNumber;
        this.bloodGroup = bloodGroup;
        this.occupation = occupation;
        this.dob = dob;
        this.mobileNumber = mobileNumber;
        this.educationQualification = educationQualification;
        this.nationality = nationality;
        this.email = email;
        this.id = id;
        this.approved = approved;
        this.deleted = deleted;
    }

    public String getApplicantName() {
        return applicantName;
    }

    public void setApplicantName(String applicantName) {
        this.applicantName = applicantName;
    }

    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public String getMotherName() {
        return motherName;
    }

    public void setMotherName(String motherName) {
        this.motherName = motherName;
    }

    public String getPresentAddress() {
        return presentAddress;
    }

    public void setPresentAddress(String presentAddress) {
        this.presentAddress = presentAddress;
    }

    public String getPermanentAddress() {
        return permanentAddress;
    }

    public void setPermanentAddress(String permanentAddress) {
        this.permanentAddress = permanentAddress;
    }

    public String getUpzillaName() {
        return upzillaName;
    }

    public void setUpzillaName(String upzillaName) {
        this.upzillaName = upzillaName;
    }

    public String getUnionName() {
        return unionName;
    }

    public void setUnionName(String unionName) {
        this.unionName = unionName;
    }

    public String getNidNumber() {
        return nidNumber;
    }

    public void setNidNumber(String nidNumber) {
        this.nidNumber = nidNumber;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getEducationQualification() {
        return educationQualification;
    }

    public void setEducationQualification(String educationQualification) {
        this.educationQualification = educationQualification;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    // Getters and setters for the new fields...

    public boolean isApproved() {
        return approved;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }
}
