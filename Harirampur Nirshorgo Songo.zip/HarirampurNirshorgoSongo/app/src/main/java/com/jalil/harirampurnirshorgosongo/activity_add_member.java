package com.jalil.harirampurnirshorgosongo;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import android.app.DatePickerDialog;

import java.util.Calendar;

import Model.data;


public class activity_add_member extends AppCompatActivity {

    private EditText applicantNameEditText, fatherNameEditText, motherNameEditText,
            presentAddressEditText, permanentAddressEditText, nidNumberEditText,
            occupationEditText, dobEditText, mobileNumberEditText,
            educationQualificationEditText, emailEditText;

    private Spinner bloodGroupSpinner, nationalitySpinner,UpzillaGroupSpinner, unionGroupSpinner;

    private Button submitButton;

    private DatabaseReference databaseReference;

    private FirebaseAuth mAuth;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_member);

        // Initialize Firebase

        mAuth= FirebaseAuth.getInstance();
        FirebaseUser mUser=mAuth.getCurrentUser();

        databaseReference = FirebaseDatabase.getInstance().getReference().child("MemberInfo");



        // Initialize vie
        applicantNameEditText = findViewById(R.id.applicantNameEditText);
        fatherNameEditText = findViewById(R.id.fatherNameEditText);
        motherNameEditText = findViewById(R.id.motherNameEditText);
        presentAddressEditText = findViewById(R.id.presentAddressEditText);
        permanentAddressEditText = findViewById(R.id.permanentAddressEditText);
        UpzillaGroupSpinner =findViewById(R.id.UpzillaGroupSpinner);
        unionGroupSpinner =findViewById(R.id.unionGroupSpinner);
        nidNumberEditText = findViewById(R.id.nidNumberEditText);
        bloodGroupSpinner = findViewById(R.id.bloodGroupSpinner);
        occupationEditText = findViewById(R.id.occupationEditText);
        dobEditText = findViewById(R.id.date_of_birth);
        mobileNumberEditText = findViewById(R.id.mobileNumberEditText);
        educationQualificationEditText = findViewById(R.id.educationQualificationEditText);
        nationalitySpinner = findViewById(R.id.nationality_spinner);
        emailEditText = findViewById(R.id.email);
        submitButton = findViewById(R.id.submit_button);


        //populate Blood Group Spinner

        ArrayAdapter<CharSequence> upzillaGroupAdapter =ArrayAdapter.createFromResource(
                this,R.array.Upzilla_options, android.R.layout.simple_spinner_item);
        UpzillaGroupSpinner.setAdapter(upzillaGroupAdapter);

        //populate union group spinner

        ArrayAdapter<CharSequence> unionGroupAdapter =ArrayAdapter.createFromResource(
                this,R.array.Union_options, android.R.layout.simple_spinner_item);

        unionGroupSpinner.setAdapter(unionGroupAdapter);
        // Populate Blood Group Spinner
        ArrayAdapter<CharSequence> bloodGroupAdapter = ArrayAdapter.createFromResource(
                this, R.array.blood_group_options, android.R.layout.simple_spinner_item
        );




        bloodGroupAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        bloodGroupSpinner.setAdapter(bloodGroupAdapter);

        // Populate Nationality Spinner
        ArrayAdapter<CharSequence> nationalityAdapter = ArrayAdapter.createFromResource(
                this, R.array.nationality_options, android.R.layout.simple_spinner_item
        );
        nationalityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        nationalitySpinner.setAdapter(nationalityAdapter);

        ImageView calendarIcon = findViewById(R.id.calendar_icon);

        // Set an OnClickListener for the calendar icon
        calendarIcon.setOnClickListener(v -> showDatePickerDialog());

        // Submit button click listener
        submitButton.setOnClickListener(view -> saveApplicantInfo());

    }private void showDatePickerDialog() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (datePicker, year, month, day) -> {
                    // Update the EditText with the selected date
                    String selectedDate = day + "/" + (month + 1) + "/" + year;
                    dobEditText.setText(selectedDate);
                },
                // Set the initial date (optional)
                1995, 0, 1 // You can change this to your desired default date
        );

        // Show the date picker dialog
        datePickerDialog.show();
    }



    private void saveApplicantInfo() {
        // Get user inputs
        String applicantName = applicantNameEditText.getText().toString().trim();
        String fatherName = fatherNameEditText.getText().toString().trim();
        String motherName = motherNameEditText.getText().toString().trim();
        String presentAddress = presentAddressEditText.getText().toString().trim();
        String permanentAddress = permanentAddressEditText.getText().toString().trim();
        String upzillaName = UpzillaGroupSpinner.getSelectedItem().toString();
        String unionName = unionGroupSpinner.getSelectedItem().toString();
        String nidNumber = nidNumberEditText.getText().toString().trim();
        String bloodGroup = bloodGroupSpinner.getSelectedItem().toString();
        String occupation = occupationEditText.getText().toString().trim();
        String dob = dobEditText.getText().toString().trim();
        String mobileNumber = mobileNumberEditText.getText().toString().trim();
        String educationQualification = educationQualificationEditText.getText().toString().trim();
        String nationality = nationalitySpinner.getSelectedItem().toString();
        String email = emailEditText.getText().toString().trim();

        // Validate inputs (you can add more validation as needed)

        if (TextUtils.isEmpty(applicantName)) {
            applicantNameEditText.setError("Required Field...");
            return;
        }
        if (TextUtils.isEmpty(mobileNumber)) {
            mobileNumberEditText.setError("Required Field...");
            return;
        }

        // Generate ID based on the current year and mobile number
        String currentYear = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        String id = currentYear + mobileNumber;

        // Create a data object to store in the database
        data memberInfo = new data(
                applicantName, fatherName, motherName, presentAddress, permanentAddress, upzillaName, unionName,
                nidNumber, bloodGroup, occupation, dob, mobileNumber,
                educationQualification, nationality, email, id, false, false
        );

        // Store the data in Firebase Realtime Database
        databaseReference.child(id).setValue(memberInfo);

        // Inform the user
        Toast.makeText(this, "Applicant information saved successfully.", Toast.LENGTH_SHORT).show();

        // Clear the input fields for the next entry
        clearFields();
    }




    private void clearFields() {
        // Clear all input fields here
        applicantNameEditText.setText("");
        fatherNameEditText.setText("");
        motherNameEditText.setText("");
        presentAddressEditText.setText("");
        permanentAddressEditText.setText("");
        UpzillaGroupSpinner.setSelection(0);
        unionGroupSpinner.setSelection(0);
        nidNumberEditText.setText("");
        bloodGroupSpinner.setSelection(0);
        occupationEditText.setText("");
        dobEditText.setText("");
        mobileNumberEditText.setText("");
        educationQualificationEditText.setText("");
        nationalitySpinner.setSelection(0);
        emailEditText.setText("");
    }
}