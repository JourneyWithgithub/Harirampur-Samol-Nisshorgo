package com.jalil.harirampurnirshorgosongo;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import Model.data;

public class EditInfoFragment extends BottomSheetDialogFragment {

    private EditText editName;
    private EditText editPhoneNumber;
    private EditText editPresentAddress;
    private EditText editOccupation;
    private EditText editEmail;

    private Button saveButton;


    public interface EditInfoListener {
        void onSaveInfo(String memberId, String newName, String newPhoneNumber,
                        String newPresentAddress, String newOccupation, String newEmail);
    }

    private EditInfoListener listener;
    private data currentData;
    private DatabaseReference databaseReference;
    private FirebaseRecyclerAdapter<data, ViewMembersActivity.MemberViewHolder> adapter;

    public void setAdapter(FirebaseRecyclerAdapter<data, ViewMembersActivity.MemberViewHolder> adapter) {
        this.adapter = adapter;
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // No need to set the listener here. We'll set the target fragment.

        if (getArguments() != null) {
            currentData = (data) getArguments().getSerializable("currentData");
        }
    }

    // Update the currentData whenever the data changes
    public void updateCurrentData(data newData) {
        currentData = newData;
        updateUI();
    }
    public void setDatabaseReference(DatabaseReference databaseReference) {
        this.databaseReference = databaseReference;
    }

    private void updateUI() {
        // Update the UI with the current data
        if (currentData != null) {
            editName.setText(currentData.getApplicantName());
            editPhoneNumber.setText(currentData.getMobileNumber());
            editPresentAddress.setText(currentData.getPresentAddress());
            editOccupation.setText(currentData.getOccupation());
            editEmail.setText(currentData.getEmail());
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_edit_info_fragment, container, false);

        editName = view.findViewById(R.id.editName);
        editPhoneNumber = view.findViewById(R.id.editPhoneNumber);
        editPresentAddress = view.findViewById(R.id.editPresentAddress);
        editOccupation = view.findViewById(R.id.editOccupation);
        editEmail = view.findViewById(R.id.editEmail);

        saveButton = view.findViewById(R.id.saveButton);
        saveButton.setOnClickListener(v -> onSaveButtonClicked());

        // Update the UI with the current data
        updateUI();

        return view;
    }

    private void onSaveButtonClicked() {
        String memberId = getArguments().getString("memberId");

        // Retrieve data from EditText fields
        String newName = editName.getText().toString().trim();
        String newPhoneNumber = editPhoneNumber.getText().toString().trim();
        String newPresentAddress = editPresentAddress.getText().toString().trim();
        String newOccupation = editOccupation.getText().toString().trim();
        String newEmail = editEmail.getText().toString().trim();

        if (databaseReference != null) {
            // Update the database only if any of the fields are not empty
            DatabaseReference memberRef = databaseReference.child(memberId);

            if (!newName.isEmpty()) {
                memberRef.child("applicantName").setValue(newName);
            }
            if (!newPhoneNumber.isEmpty()) {
                memberRef.child("mobileNumber").setValue(newPhoneNumber);
            }
            if (!newPresentAddress.isEmpty()) {
                memberRef.child("presentAddress").setValue(newPresentAddress);
            }
            if (!newOccupation.isEmpty()) {
                memberRef.child("occupation").setValue(newOccupation);
            }
            if (!newEmail.isEmpty()) {
                memberRef.child("email").setValue(newEmail);
            }

            showToast("Saving changes...");
        } else {
            showToast("Error: Database reference is null");
        }




        dismiss();
    }



    private void showToast(String message) {
        Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
    }
}