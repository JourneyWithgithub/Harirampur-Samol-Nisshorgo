package com.jalil.harirampurnirshorgosongo;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

import Model.data;

public class client_request extends AppCompatActivity {

    private Toolbar toolbar;
    private RecyclerView recyclerView;

    private FirebaseRecyclerAdapter<data, MemberViewHolder> adapter;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_request);

        // Initialize the Toolbar
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Pending Request");

        // Initialize the RecyclerView
        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Set up Firebase database reference
        databaseReference = FirebaseDatabase.getInstance().getReference("MemberInfo");

        // Set up FirebaseRecyclerOptions and FirebaseRecyclerAdapter
        Query query = databaseReference.orderByChild("approved").equalTo(false); // Filter only pending requests
        FirebaseRecyclerOptions<data> options = new FirebaseRecyclerOptions.Builder<data>()
                .setQuery(query, data.class)
                .build();

        adapter = new FirebaseRecyclerAdapter<data, MemberViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull MemberViewHolder holder, int position, @NonNull data model) {
                holder.bindMember(model);
            }

            @NonNull
            @Override
            public MemberViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_member_summary1, parent, false);
                return new MemberViewHolder(view);
            }
        };

        recyclerView.setAdapter(adapter);
    }

    // Define the ViewHolder class
    public class MemberViewHolder extends RecyclerView.ViewHolder {
        private final TextView nameTextView;
        private final TextView phoneNumberTextView;
        private final LinearLayout expandedView;
        private final Button btnApprove;
        private final Button btnRemove;

        public MemberViewHolder(@NonNull View itemView) {
            super(itemView);

            nameTextView = itemView.findViewById(R.id.memberNameTextView);
            phoneNumberTextView = itemView.findViewById(R.id.memberPhoneNumberTextView);
            expandedView = itemView.findViewById(R.id.expandedView);
            btnApprove = itemView.findViewById(R.id.btnApprove);
            btnRemove = itemView.findViewById(R.id.btnRemove);

            // Set click listeners for the approve and remove buttons
            btnApprove.setOnClickListener(view -> approveMember(getAdapterPosition()));
            btnRemove.setOnClickListener(view -> removeMember(getAdapterPosition()));

            // Set click listener for the "Read More" button to toggle visibility of details
            itemView.findViewById(R.id.readMoreButton).setOnClickListener(view -> toggleExpandedView());
        }

        private void toggleExpandedView() {
            // Toggle the visibility of the expanded view
            if (expandedView.getVisibility() == View.VISIBLE) {
                expandedView.setVisibility(View.GONE);
            } else {
                expandedView.setVisibility(View.VISIBLE);
            }
        }

        private void approveMember(int position) {
            // Get the key of the item in the Firebase database
            String itemKey = adapter.getRef(position).getKey();

            // Update the item's status to approved in the database
            databaseReference.child(itemKey).child("approved").setValue(true)
                    .addOnSuccessListener(aVoid -> {
                        showToast("Member Approved");
                    })
                    .addOnFailureListener(e -> {
                        showToast("Failed to approve member");
                    });
        }

        private void removeMember(int position) {
            // Remove the item from the RecyclerView's adapter
            adapter.getSnapshots().getSnapshot(position).getRef().removeValue();
            showToast("Member Removed");
        }

        private void showToast(String message) {
            Toast.makeText(itemView.getContext(), message, Toast.LENGTH_SHORT).show();
        }

        public void bindMember(data member) {
            nameTextView.setText(member.getApplicantName());
            phoneNumberTextView.setText(member.getMobileNumber());
            expandedView.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}
