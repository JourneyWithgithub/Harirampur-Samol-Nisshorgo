package com.jalil.harirampurnirshorgosongo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.os.Bundle;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.os.Environment;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class SearchResult extends AppCompatActivity {

    private static final int REQUEST_WRITE_EXTERNAL_STORAGE = 1;
    private TextView nameTextView;
    private TextView phoneNumberTextView;
    private TextView presentAddressTextView;
    private TextView motherNameTextView;
    private TextView fatherNameTextView;
    private TextView addressTextView;
    private TextView permanentAddressTextView;
    private TextView nidTextView;
    private TextView bloodGroupTextView;
    private TextView occupationTextView;
    private TextView dateofbirthTextView;
    private TextView educationQualificationTextView;
    private TextView nationalityTextView;
    private TextView emailTextView;
    private Button download;

    @SuppressLint("CutPasteId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_result);

        nameTextView = findViewById(R.id.memberNameTextView);
        phoneNumberTextView = findViewById(R.id.memberPhoneNumberTextView);
        fatherNameTextView = findViewById(R.id.memberFatherNameTextView);
        motherNameTextView = findViewById(R.id.memberMotherNameTextView);
        addressTextView = findViewById(R.id.memberPresentAddressTextView);
        presentAddressTextView = findViewById(R.id.memberPresentAddressTextView);
        permanentAddressTextView = findViewById(R.id.memberPermanentAddressTextView);
        nidTextView = findViewById(R.id.memberNidNumberTextView);
        bloodGroupTextView = findViewById(R.id.memberBloodGroupTextView);
        occupationTextView = findViewById(R.id.memberOccupationTextView);
        dateofbirthTextView = findViewById(R.id.memberDobTextView);
        educationQualificationTextView = findViewById(R.id.memberEducationQualificationTextView);
        nationalityTextView = findViewById(R.id.memberNationalityTextView);
        emailTextView = findViewById(R.id.memberEmailTextView);
        download = findViewById(R.id.Download);

        Intent intent = getIntent();
        String uid = intent.getStringExtra("code");

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference();
        DatabaseReference userReference = databaseReference.child("MemberInfo").child(uid);

        userReference.addValueEventListener(new ValueEventListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String applicantName = dataSnapshot.child("applicantName").getValue(String.class);
                    String bloodGroup = dataSnapshot.child("bloodGroup").getValue(String.class);
                    String email = dataSnapshot.child("email").getValue(String.class);
                    String dob = dataSnapshot.child("dob").getValue(String.class);
                    String educationalQualification = dataSnapshot.child("educationalQualification").getValue(String.class);
                    String fatherName = dataSnapshot.child("fatherName").getValue(String.class);
                    String mobileNumber = dataSnapshot.child("mobileNumber").getValue(String.class);
                    String motherName = dataSnapshot.child("motherName").getValue(String.class);
                    String nationality = dataSnapshot.child("nationality").getValue(String.class);
                    String nidNumber = dataSnapshot.child("nidNumber").getValue(String.class);
                    String occupation = dataSnapshot.child("occupation").getValue(String.class);
                    String permanentAddress = dataSnapshot.child("permanentAddress").getValue(String.class);
                    String presentAddress = dataSnapshot.child("presentAddress").getValue(String.class);

                    nameTextView.setText("Applicant's Name: " + applicantName);
                    phoneNumberTextView.setText("Applicant's Phone: " + mobileNumber);
                    fatherNameTextView.setText("Father's Name: " + fatherName);
                    motherNameTextView.setText("Mother's Name: " + motherName);
                    presentAddressTextView.setText("Present Address: " + presentAddress);

                    addressTextView.setText("Address: " + presentAddress);
                    permanentAddressTextView.setText("Permanent Address: " + permanentAddress);
                    nidTextView.setText("NID: " + nidNumber);
                    bloodGroupTextView.setText("Blood Group: " + bloodGroup);
                    occupationTextView.setText("Occupation: " + occupation);
                    dateofbirthTextView.setText("Date of Birth: " + dob);
                    educationQualificationTextView.setText("Educational Qualification: " + educationalQualification);
                    nationalityTextView.setText("Nationality: " + nationality);
                    emailTextView.setText("Email: " + email);
                } else {
                    Context context = getApplicationContext();
                    CharSequence text = "Data doesn't exist for the provided UID";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("Firebase", "Error: " + databaseError.getMessage());
            }
        });

        download.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                generatePDF("");
            }
            else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_WRITE_EXTERNAL_STORAGE);
                generatePDF("");

            }
        });
    }



    private void generatePDF(String filename) {
        PdfDocument pdfDocument = new PdfDocument();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(595, 842, 1).create(); // Adjust page size as needed.
        PdfDocument.Page page = pdfDocument.startPage(pageInfo);

        Canvas canvas = page.getCanvas();
        Paint paint = new Paint();
        Paint paint1 = new Paint();

        // Set up the paint for text, e.g., font size, color, etc.
        paint.setTextSize(22); // Adjust text size as needed
        paint1.setTextSize(28);
        paint.setColor(Color.BLACK);

        // Define the layout and position for your content.
        int leftMargin = 50;
        int topMargin = 50;

        // Add your content to the canvas.
        canvas.drawText("Applicant's Details: ", 200, 30, paint1);

        topMargin += 40; // Increase the topMargin to separate lines

        canvas.drawText( ""+nameTextView.getText(), leftMargin, topMargin, paint);
        topMargin += 40;
        canvas.drawText("" + phoneNumberTextView.getText(), leftMargin, topMargin, paint);
        topMargin += 40;
        canvas.drawText("" + fatherNameTextView.getText(), leftMargin, topMargin, paint);
        topMargin += 40;
        canvas.drawText("" + motherNameTextView.getText(), leftMargin, topMargin, paint);
        topMargin += 40;
        canvas.drawText("" + presentAddressTextView.getText(), leftMargin, topMargin, paint);
        topMargin += 40;
        canvas.drawText("" + addressTextView.getText(), leftMargin, topMargin, paint);
        topMargin += 40;
        canvas.drawText("" + permanentAddressTextView.getText(), leftMargin, topMargin, paint);
        topMargin += 40;
        canvas.drawText("" + nidTextView.getText(), leftMargin, topMargin, paint);
        topMargin += 40;
        canvas.drawText("" + bloodGroupTextView.getText(), leftMargin, topMargin, paint);
        topMargin += 40;
        canvas.drawText("" + occupationTextView.getText(), leftMargin, topMargin, paint);
        topMargin += 40;
        canvas.drawText("" + dateofbirthTextView.getText(), leftMargin, topMargin, paint);
        topMargin += 40;
        canvas.drawText("" + educationQualificationTextView.getText(), leftMargin, topMargin, paint);
        topMargin += 40;
        canvas.drawText("" + nationalityTextView.getText(), leftMargin, topMargin, paint);
        topMargin += 40;
        canvas.drawText("" + emailTextView.getText(), leftMargin, topMargin, paint);

        // Add more text and other content as needed.

        pdfDocument.finishPage(page);

        EditText pdfFileNameEditText = findViewById(R.id.pdfFileNameEditText);
        String pdfFileName = pdfFileNameEditText.getText().toString().trim();

        if (pdfFileName.isEmpty() && filename.isEmpty()) {
            // Prompt the user for a file name using a Dialog
            showFileNameInputDialog();
        } else {
            // Define the file path to the "Downloads" folder.
            File downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            File pdfFile = new File(downloadDir, (pdfFileName.isEmpty() ? filename : pdfFileName) + ".pdf");

            if (pdfFile.exists()) {
                // Display a message that the file already exists.
                Toast.makeText(this, "File already exists in the Downloads folder.", Toast.LENGTH_SHORT).show();
                showFileNameInputDialog();
            } else {
                try {
                    pdfDocument.writeTo(new FileOutputStream(pdfFile));
                    pdfDocument.close();
                    Toast.makeText(this, "PDF saved successfully in the Downloads folder as " + pdfFile.getName(), Toast.LENGTH_SHORT).show();

                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(this, "PDF generation failed.", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }


    private void showFileNameInputDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter PDF File Name");

        // Set up the input field in the dialog
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input);


        // Set up the OK button to save the PDF with the entered name
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String pdfFileName = input.getText().toString().trim();
                if (!pdfFileName.isEmpty()) {
                    generatePDF(pdfFileName);
                    dialog.dismiss();
                    // Recursively call generatePDF with the entered name
                } else {
                    // Handle the case when the user didn't enter a valid name
                    Toast.makeText(SearchResult.this, "Invalid file name. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set up the Cancel button
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.show();


    }

}
