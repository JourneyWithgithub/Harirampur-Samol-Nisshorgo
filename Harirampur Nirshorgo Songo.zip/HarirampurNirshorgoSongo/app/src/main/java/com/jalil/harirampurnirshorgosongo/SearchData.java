package com.jalil.harirampurnirshorgosongo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class SearchData extends AppCompatActivity {

    private EditText searchEditText;
    private Button searchButton;
    private TextView searchResultsTextView;
    private DatabaseReference mechanicReference;
    private Handler searchHandler = new Handler();
    private Runnable searchRunnable;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_data);

        searchEditText = findViewById(R.id.searchEditText);
        searchButton = findViewById(R.id.searchButton);
        searchResultsTextView = findViewById(R.id.searchResultsTextView);


        // Initialize the Firebase Realtime Database reference for the "Mechanic" node
        mechanicReference = FirebaseDatabase.getInstance().getReference().child("MemberInfo");

        // Attach a TextWatcher to the searchEditText for real-time updates
        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                   searchHandler.removeCallbacks(searchRunnable);

                searchRunnable = () -> {
              String searchTerm = charSequence.toString().trim();

              if(searchTerm != "") performSearchName(searchTerm);
              else performSearchName(searchTerm);
                };

                searchHandler.postDelayed(searchRunnable, 1000);
            }

            @Override
            public void afterTextChanged(Editable editable) {
                //searchHandler.removeCallbacks(searchRunnable);

                //searchRunnable = new Runnable() {
                  //  @Override
                    //public void run() {
                      //  String searchTerm = editable.toString().trim();
                        //performSearchName(searchTerm);
                    //}
                //};

                //searchHandler.postDelayed(searchRunnable, 500); // Adjust the delay as needed


            }
        });

        searchButton.setOnClickListener(view -> {
            String searchTerm = searchEditText.getText().toString().trim();
            performSearchName(searchTerm);
        });
    }

    private void performSearchName(String searchTerm) {

        Set<String> results = new HashSet<>();

        if (searchTerm.isEmpty()) {
            // Clear the search results and return
            searchResultsTextView.setText("Search Result will be displayed here");

        }

       else {

           // Query queryByName = mechanicReference.orderByChild("applicantName").startAt(searchTerm1).endAt(searchTerm1 +"\uf8ff");
            mechanicReference.addListenerForSingleValueEvent(new ValueEventListener() {

                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    results.clear();
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        String searchString = "";
                        String applicantName = snapshot.child("applicantName").getValue(String.class);
                        String bloodGroup = snapshot.child("bloodGroup").getValue(String.class);
                        String email = snapshot.child("email").getValue(String.class);
                        String dob = snapshot.child("dob").getValue(String.class);
                        String educationalQualification = snapshot.child("educationalQualification").getValue(String.class);
                        String fatherName = snapshot.child("fatherName").getValue(String.class);
                        String mobileNumber = snapshot.child("mobileNumber").getValue(String.class);
                        String motherName = snapshot.child("motherName").getValue(String.class);
                        String nationality = snapshot.child("nationality").getValue(String.class);
                        String nidNumber = snapshot.child("nidNumber").getValue(String.class);
                        String occupation = snapshot.child("occupation").getValue(String.class);
                        String permanentAddress = snapshot.child("permanentAddress").getValue(String.class);
                        String presentAddress = snapshot.child("presentAddress").getValue(String.class);

                        searchString += (applicantName+"  "+ bloodGroup+"  "+email+"  "+dob+"  "+fatherName +"  "+ mobileNumber +"  "+ motherName +"  "+ nidNumber +"  "+ permanentAddress +"  "+ presentAddress);

                        if (searchString != "") {
                            String d1 = searchString.toLowerCase();
                            String d2 = searchTerm.toLowerCase();
                            // Create and display a short duration toast message
                            if (d1.contains(d2)) { // Case-insensitive search for substring
                                String uid = snapshot.getKey();
                                results.add(uid);
                            }
                        }
                    }

                    displaySearchResults(new ArrayList<>(results));
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Log.e("SearchData", "Search failed: " + databaseError.getMessage());
                    searchResultsTextView.setText("Search failed. Please try again later.");
                }
            });
        }
    }



    private void displaySearchResults(List<String> results) {
        if (results.isEmpty()) {
            searchResultsTextView.setText("No results found.");
        } else {
            SpannableStringBuilder resultText = new SpannableStringBuilder();
            final int[] startIndex = {0}; // Start index for each row

            for (String uid : results) {
                // Retrieve data associated with the UID
                mechanicReference.child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String applicantName = dataSnapshot.child("applicantName").getValue(String.class);
                        String fatherName = dataSnapshot.child("fatherName").getValue(String.class);
                        String mobileNumber = dataSnapshot.child("mobileNumber").getValue(String.class);
                        String presentAddress = dataSnapshot.child("presentAddress").getValue(String.class);
                        // Create a row

                        String row = "Applicant Name:   " + applicantName + ",   Mobile Number:   " + mobileNumber + ",   Father's Name:   " + fatherName + ", Present Address:   " + presentAddress;

                        // Append the row to the resultText
                        resultText.append(row).append("\n\n\n");

                        // Create a ClickableSpan for the entire row
                        ClickableSpan clickableSpan = new ClickableSpan() {
                            @Override
                            public void onClick(@NonNull View widget) {
                                // Handle the click action here
                                // For example, you can open the SearchResult activity
                                Intent intent = new Intent(SearchData.this, SearchResult.class);

                                String message = uid;
                                intent.putExtra("code", message);

                                startActivity(intent);
                            }
                        };

                        // Set the ClickableSpan for the entire row
                        resultText.setSpan(clickableSpan, startIndex[0], startIndex[0] + row.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

                        // Update the startIndex for the next row
                        startIndex[0] += row.length() + 1; // +1 for the newline character

                        // Update the searchResultsTextView
                        searchResultsTextView.setText(resultText);
                        searchResultsTextView.setMovementMethod(LinkMovementMethod.getInstance());
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        searchResultsTextView.setText("Search failed. Please try again later.");
                    }
                });
            }
        }
    }



}
