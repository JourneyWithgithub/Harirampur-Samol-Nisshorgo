package com.jalil.harirampurnirshorgosongo;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

import Model.data;

public class ViewMembersActivity extends AppCompatActivity implements EditInfoFragment.EditInfoListener {

    private Toolbar toolbar;
    private EditText searchEditText;
    private RecyclerView recyclerView;

    private Handler searchHandler = new Handler();
    private Runnable searchRunnable;
    private FirebaseRecyclerAdapter<data, MemberViewHolder> adapter;
    private DatabaseReference databaseReference;
    private Query query;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_members);

        // Initialize the Toolbar
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setTitle("Members");

        // Remove the searchEditText initialization and related code

        // Initialize the RecyclerView
        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Set up Firebase database reference
        databaseReference = FirebaseDatabase.getInstance().getReference("MemberInfo");

        // Set up FirebaseRecyclerOptions and FirebaseRecyclerAdapter
        query = databaseReference;
        FirebaseRecyclerOptions<data> options = new FirebaseRecyclerOptions.Builder<data>()
                .setQuery(query, data.class)
                .build();

        adapter = new FirebaseRecyclerAdapter<data, MemberViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull MemberViewHolder holder, int position, @NonNull data model) {
                holder.bindMember(model);
            }

            @NonNull
            @Override
            public MemberViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_member_summary, parent, false);
                return new MemberViewHolder(view);
            }
        };

        recyclerView.setAdapter(adapter);
    }



    // Define the ViewHolder class
    public class MemberViewHolder extends RecyclerView.ViewHolder {
        private final TextView nameTextView;
        private final TextView phoneNumberTextView;
        private final TextView presentAddressTextView;
        private final TextView motherNameTextView;
        private final TextView fatherNameTextView;
        private final TextView addressTextView;
        private final TextView permanentAddressTextView;
        private final TextView nidTextView;
        private final TextView bloodGroupTextView;
        private final TextView occupationTextView;
        private final TextView dateofbirthTextView;
        private final TextView educationQualificationTextView;
        private final TextView nationalityTextView;
        private final TextView emailTextView;
        private final TextView idTextView;
        private final Button readMoreButton;
        private final LinearLayout expandedView;
        private boolean isExpanded = false;

        private ImageView Editbtn, Deletebtn;

        private DatabaseReference databaseReference;
        private data currentData;

        @SuppressLint("CutPasteId")
        public MemberViewHolder(@NonNull View itemView) {
            super(itemView);

            nameTextView = itemView.findViewById(R.id.memberNameTextView);
            phoneNumberTextView = itemView.findViewById(R.id.memberPhoneNumberTextView);
            fatherNameTextView = itemView.findViewById(R.id.memberFatherNameTextView);
            motherNameTextView = itemView.findViewById(R.id.memberMotherNameTextView);
            presentAddressTextView = itemView.findViewById(R.id.memberPresentAddressTextView);
            addressTextView = itemView.findViewById(R.id.memberPresentAddressTextView);
            permanentAddressTextView = itemView.findViewById(R.id.memberPermanentAddressTextView);
            nidTextView = itemView.findViewById(R.id.memberNidNumberTextView);
            bloodGroupTextView = itemView.findViewById(R.id.memberBloodGroupTextView);
            occupationTextView = itemView.findViewById(R.id.memberOccupationTextView);
            dateofbirthTextView = itemView.findViewById(R.id.memberDobTextView);
            educationQualificationTextView = itemView.findViewById(R.id.memberEducationQualificationTextView);
            nationalityTextView = itemView.findViewById(R.id.memberNationalityTextView);
            emailTextView = itemView.findViewById(R.id.memberEmailTextView);
            idTextView = itemView.findViewById(R.id.memberIdTextView);
            readMoreButton = itemView.findViewById(R.id.readMoreButton);
            expandedView = itemView.findViewById(R.id.expandedView);
            Editbtn = itemView.findViewById(R.id.editIconExpanded);
            Deletebtn = itemView.findViewById(R.id.deleteIconExpanded);


            databaseReference = FirebaseDatabase.getInstance().getReference("MemberInfo");
            // Set click listeners for the edit and delete icons

            Editbtn.setOnClickListener(view -> showEditBottomSheet(adapter.getRef(getAdapterPosition()).getKey()));
            Deletebtn.setOnClickListener(view -> deleteMember(adapter.getRef(getAdapterPosition()).getKey()));



            // Set click listener for the "Read More" button to toggle visibility of details
            readMoreButton.setOnClickListener(view -> {
                // Toggle the visibility of the expanded view
                if (isExpanded) {
                    expandedView.setVisibility(View.GONE);
                    readMoreButton.setText("Read More"); // Change button text
                } else {
                    expandedView.setVisibility(View.VISIBLE);
                    readMoreButton.setText("Read Less"); // Change button text
                }
                // Update the state flag
                isExpanded = !isExpanded;
            });

        }

        private void showEditBottomSheet(String memberId) {
            // Create an instance of your BottomSheetDialogFragment
            EditInfoFragment editInfoFragment = new EditInfoFragment();

            // Pass the selected member's information to the fragment
            Bundle bundle = new Bundle();
            bundle.putString("memberId", memberId);
            bundle.putSerializable("currentData", currentData);  // Add this line
            editInfoFragment.setArguments(bundle);

            // Set the database reference in the fragment
            editInfoFragment.setDatabaseReference(databaseReference);


            // Show the BottomSheetDialogFragment
            FragmentManager fragmentManager = getSupportFragmentManager();
            editInfoFragment.show(fragmentManager, editInfoFragment.getTag());


        }



        private void deleteMember(String memberId) {


            if (databaseReference == null) {
                // Handle the null reference, log an error, or show a toast
                showToast("Database reference is null");
                return;
            }
            DatabaseReference memberRef = databaseReference.child(memberId);

            // Remove data from the "MemberInfo" database
            memberRef.removeValue()
                    .addOnSuccessListener(aVoid -> {
                        // If the data is successfully deleted from the "MemberInfo" database,
                        // you can display a toast indicating success
                        showToast("Member deleted successfully");
                    })
                    .addOnFailureListener(e -> {
                        // Failed to delete from the "MemberInfo" database
                        showToast("Failed to delete member");
                    });
        }


        private void showToast(String message) {
            Toast.makeText(itemView.getContext(), message, Toast.LENGTH_SHORT).show();
        }



        @SuppressLint("SetTextI18n")
        public void bindMember(data member) {
            nameTextView.setText(member.getApplicantName());
            phoneNumberTextView.setText(member.getMobileNumber());
            fatherNameTextView.setText("Father's Name: " + member.getFatherName());
            motherNameTextView.setText("Mother's Name: " + member.getMotherName());
            presentAddressTextView.setText("Present Address: " + member.getPresentAddress());
            addressTextView.setText("Present Address: " + member.getPresentAddress());
            permanentAddressTextView.setText("Permanent Address: " + member.getPermanentAddress());
            nidTextView.setText("NID: " + member.getNidNumber());
            bloodGroupTextView.setText("Blood Group: " + member.getBloodGroup());
            occupationTextView.setText("Occupation: " + member.getOccupation());
            dateofbirthTextView.setText("Date of Birth: " + member.getDob());
            educationQualificationTextView.setText("Educational Qualification: " + member.getEducationQualification());
            nationalityTextView.setText("Nationality: " + member.getNationality());
            emailTextView.setText("Email: " + member.getEmail());
            idTextView.setText("ID: " + member.getId());
            expandedView.setVisibility(View.GONE);

            // Set click listener for the "Read More" button to toggle visibility of details
            readMoreButton.setOnClickListener(view -> {
                // Toggle the visibility of the expanded view
                if (isExpanded) {
                    expandedView.setVisibility(View.GONE);
                    readMoreButton.setText("Read More"); // Change button text
                } else {
                    expandedView.setVisibility(View.VISIBLE);
                    readMoreButton.setText("Read Less"); // Change button text
                }
                // Update the state flag
                isExpanded = !isExpanded;
            });
        }
    }


// Implement the onSaveInfo method from EditInfoListener
    @Override
    public void onSaveInfo(String memberId, String newName, String newPhoneNumber, String newPresentAddress, String newOccupation, String newEmail) {
        // Update only the specific fields in the database
        DatabaseReference memberRef = databaseReference.child(memberId);
        if (newName != null && !newName.isEmpty()) {
            memberRef.child("applicantName").setValue(newName);
        }
        if (newPhoneNumber != null && !newPhoneNumber.isEmpty()) {
            memberRef.child("mobileNumber").setValue(newPhoneNumber);
        }
        if (newPresentAddress != null && !newPresentAddress.isEmpty()) {
            memberRef.child("presentAddress").setValue(newPresentAddress);
        }
        if (newOccupation != null && !newOccupation.isEmpty()) {
            memberRef.child("occupation").setValue(newOccupation);
        }
        if (newEmail != null && !newEmail.isEmpty()) {
            memberRef.child("email").setValue(newEmail);
        }

        // Notify the adapter that the data has changed
        adapter.notifyDataSetChanged();

        // Show a toast message indicating success
        showToast("Member information updated successfully");
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }



    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}