package com.jalil.harirampurnirshorgosongo;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegistrationActivity extends AppCompatActivity {
    private EditText emailReg;
    private EditText passReg;
    private Button btnReg;
    private Button btnLogin;
    private TextView passwordError;
    private ImageButton btnTogglePassword;

    private FirebaseAuth mAuth;
    private ProgressDialog mDialog;
    private boolean passwordVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        mAuth = FirebaseAuth.getInstance();
        mDialog = new ProgressDialog(this);

        emailReg = findViewById(R.id.email_registration);
        passReg = findViewById(R.id.registration_password);
        btnReg = findViewById(R.id.btn_registration);
        btnLogin = findViewById(R.id.btn_login);
        passwordError = findViewById(R.id.password_error);
        btnTogglePassword = findViewById(R.id.btnTogglePassword);

        btnTogglePassword.setOnClickListener(v -> togglePasswordVisibility());

        btnReg.setOnClickListener(v -> {
            String email = emailReg.getText().toString().trim();
            String pass = passReg.getText().toString().trim();
            if (TextUtils.isEmpty(email)) {
                emailReg.setError("Required Field...");
                return;
            }

            if (TextUtils.isEmpty(pass)) {
                passReg.setError("Required Field");
                return;
            }

            if (pass.length() < 6) {
                passwordError.setVisibility(View.VISIBLE);
                return;
            } else {
                passwordError.setVisibility(View.GONE);
            }

            mDialog.setMessage("Processing...");
            mDialog.show();

            mAuth.createUserWithEmailAndPassword(email, pass).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    sendVerificationEmail();
                    //after successfull email verification
                    //go to mainactivity like  startActivity(new Intent(getApplicationContext(), MainActivity.class)));
                } else {
                    Toast.makeText(getApplicationContext(), "Registration Failed...", Toast.LENGTH_SHORT).show();
                    mDialog.dismiss();
                }
            });
        });


        btnLogin.setOnClickListener(v -> startActivity(new Intent(getApplicationContext(), HomeActivity.class)));
    }

    private void togglePasswordVisibility() {
        if (passwordVisible) {
            passReg.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            passwordVisible = false;
            btnTogglePassword.setImageResource(R.drawable.ic_eye_off);
        } else {
            passReg.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            passwordVisible = true;
            btnTogglePassword.setImageResource(R.drawable.ic_eye);
        }
        passReg.setSelection(passReg.getText().length());
    }

    private void sendVerificationEmail() {
        mAuth.getCurrentUser().sendEmailVerification().addOnSuccessListener(unused -> {
            mDialog.dismiss();
            Toast.makeText(RegistrationActivity.this, "Email Verification link sent to your email. Please verify and then sign in", Toast.LENGTH_SHORT).show();
        }).addOnFailureListener(e -> {
            mDialog.dismiss();
            Toast.makeText(RegistrationActivity.this, "Email not sent", Toast.LENGTH_SHORT).show();
        });
    }
}
