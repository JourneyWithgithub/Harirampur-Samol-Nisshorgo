package com.jalil.harirampurnirshorgosongo;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import Model.data;

public class ViewMembeersActivity2 extends AppCompatActivity {

    private RecyclerView recyclerView;
    private FirebaseRecyclerAdapter<data, MemberViewHolder> adapter;
    private DatabaseReference databaseReference;
    private DatabaseReference query;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_membeers2);

        // Initialize the RecyclerView
        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Set up Firebase database reference
        databaseReference = FirebaseDatabase.getInstance().getReference("MemberInfo");

        // Set up FirebaseRecyclerOptions and FirebaseRecyclerAdapter
        query = databaseReference;
        FirebaseRecyclerOptions<data> options = new FirebaseRecyclerOptions.Builder<data>()
                .setQuery(query, data.class)
                .build();

        adapter = new FirebaseRecyclerAdapter<data, MemberViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull MemberViewHolder holder, int position, @NonNull data model) {
                holder.bindMember(model);
            }

            @NonNull
            @Override
            public MemberViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_member_summary3, parent, false);
                return new MemberViewHolder(view);
            }
        };

        recyclerView.setAdapter(adapter);
    }

    // Define the ViewHolder class
    public static class MemberViewHolder extends RecyclerView.ViewHolder {
        private final TextView nameTextView;
        private final TextView phoneNumberTextView;
        private final TextView fatherNameTextView;
        private final TextView motherNameTextView;
        private final TextView presentAddressTextView;
        private final TextView permanentAddressTextView;
        private final TextView nidTextView;
        private final TextView bloodGroupTextView;
        private final TextView occupationTextView;
        private final TextView dateOfBirthTextView;
        private final TextView educationQualificationTextView;
        private final TextView nationalityTextView;
        private final TextView emailTextView;
        private final TextView idTextView;
        private final Button readMoreButton;
        private final LinearLayout collapsedView;
        private final LinearLayout expandedView;
        private boolean isExpanded = false;

        public MemberViewHolder(@NonNull View itemView) {
            super(itemView);

            nameTextView = itemView.findViewById(R.id.memberNameTextView);
            phoneNumberTextView = itemView.findViewById(R.id.memberPhoneNumberTextView);
            fatherNameTextView = itemView.findViewById(R.id.memberFatherNameTextView);
            motherNameTextView = itemView.findViewById(R.id.memberMotherNameTextView);
            presentAddressTextView = itemView.findViewById(R.id.memberPresentAddressTextView);
            permanentAddressTextView = itemView.findViewById(R.id.memberPermanentAddressTextView);
            nidTextView = itemView.findViewById(R.id.memberNidNumberTextView);
            bloodGroupTextView = itemView.findViewById(R.id.memberBloodGroupTextView);
            occupationTextView = itemView.findViewById(R.id.memberOccupationTextView);
            dateOfBirthTextView = itemView.findViewById(R.id.memberDobTextView);
            educationQualificationTextView = itemView.findViewById(R.id.memberEducationQualificationTextView);
            nationalityTextView = itemView.findViewById(R.id.memberNationalityTextView);
            emailTextView = itemView.findViewById(R.id.memberEmailTextView);
            idTextView = itemView.findViewById(R.id.memberIdTextView);
            readMoreButton = itemView.findViewById(R.id.readMoreButton);
            collapsedView = itemView.findViewById(R.id.collapsedView);
            expandedView = itemView.findViewById(R.id.expandedView);

            // Set click listener for the "Read More" button to toggle visibility of details
            readMoreButton.setOnClickListener(view -> {
                // Toggle the visibility of the expanded view
                if (isExpanded) {
                    expandedView.setVisibility(View.GONE);
                    readMoreButton.setText("Read More"); // Change button text
                } else {
                    expandedView.setVisibility(View.VISIBLE);
                    readMoreButton.setText("Read Less"); // Change button text
                }
                // Update the state flag
                isExpanded = !isExpanded;
            });
        }

        public void bindMember(data member) {
            nameTextView.setText(member.getApplicantName());
            phoneNumberTextView.setText(member.getMobileNumber());
            fatherNameTextView.setText("Father's Name: " + member.getFatherName());
            motherNameTextView.setText("Mother's Name: " + member.getMotherName());
            presentAddressTextView.setText("Present Address: " + member.getPresentAddress());
            permanentAddressTextView.setText("Permanent Address: " + member.getPermanentAddress());
            nidTextView.setText("NID: " + member.getNidNumber());
            bloodGroupTextView.setText("Blood Group: " + member.getBloodGroup());
            occupationTextView.setText("Occupation: " + member.getOccupation());
            dateOfBirthTextView.setText("Date of Birth: " + member.getDob());
            educationQualificationTextView.setText("Education Qualification: " + member.getEducationQualification());
            nationalityTextView.setText("Nationality: " + member.getNationality());
            emailTextView.setText("Email: " + member.getEmail());
            idTextView.setText("ID: " + member.getId());
            collapsedView.setVisibility(isExpanded ? View.GONE : View.VISIBLE);
            expandedView.setVisibility(isExpanded ? View.VISIBLE : View.GONE);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}
