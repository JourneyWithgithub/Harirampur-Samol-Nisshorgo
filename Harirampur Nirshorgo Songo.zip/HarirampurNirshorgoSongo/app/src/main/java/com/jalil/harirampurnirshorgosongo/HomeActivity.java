package com.jalil.harirampurnirshorgosongo;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class HomeActivity extends AppCompatActivity {



    private EditText email;
    private EditText password;
    private Button btnLogin;
    private Button btnRegistration;
    private ImageButton btnTogglePassword;
    private TextView textViewForgetPassword;

    private FirebaseAuth mAuth;
    private ProgressDialog mDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        mAuth = FirebaseAuth.getInstance();

        mDialog = new ProgressDialog(this);

        LoginFunction();
    }

    private void LoginFunction() {

        email = findViewById(R.id.email_login);
        password = findViewById(R.id.login_password);
        btnLogin = findViewById(R.id.btn_login);
        btnRegistration = findViewById(R.id.btn_reg);
        btnTogglePassword = findViewById(R.id.btnTogglePassword); // Initialize eye button
        textViewForgetPassword = findViewById(R.id.textViewForgetPassword);

        btnLogin.setOnClickListener(v -> {
            String mEmail = email.getText().toString().trim();
            String pass = password.getText().toString().trim();

            if (TextUtils.isEmpty(mEmail)) {
                email.setError("Required Field...");
                return;
            }
            if (TextUtils.isEmpty(pass)) {
                password.setError("Required Field...");
                return;
            }

            mDialog.setMessage("Processing...");
            mDialog.show();

            mAuth.signInWithEmailAndPassword(mEmail, pass).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    String[] allowedEmails = {"delowar@mbstu.ac.bd", "pranabpaul30ju@gmail.com", "ajtamjid@gmail.com"};

                    boolean isAllowedEmail = false;
                    for (String allowedEmail : allowedEmails) {
                        if (allowedEmail.equals(mAuth.getCurrentUser().getEmail())) {
                            isAllowedEmail = true;
                            break;
                        }
                    }

                    if (isAllowedEmail) {
                        Toast.makeText(getApplicationContext(), "Successful", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(HomeActivity.this, MainActivity.class));
                    } else {
                        Toast.makeText(getApplicationContext(), "Successful", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(HomeActivity.this, MainActivity2.class));
                    }

                    mDialog.dismiss();
                } else {
                    Toast.makeText(getApplicationContext(), task.getException().toString(), Toast.LENGTH_SHORT).show();
                }
            });

        });

        btnRegistration.setOnClickListener(v -> startActivity(new Intent(HomeActivity.this, RegistrationActivity.class)));

        // Toggle password visibility when eye button is clicked
        btnTogglePassword.setOnClickListener(v -> {


            if (password.getInputType() == 129) {
                password.setInputType(145);
                btnTogglePassword.setImageResource(R.drawable.ic_eye);
            }
            else {
                password.setInputType(129);
                btnTogglePassword.setImageResource(R.drawable.ic_eye_off);
            }




            // Move cursor to the end of the password
            password.setSelection(password.getText().length());
        });

        textViewForgetPassword.setOnClickListener(v -> startActivity(new Intent(HomeActivity.this, ForgotPasswordActivity.class)));
    }

}
