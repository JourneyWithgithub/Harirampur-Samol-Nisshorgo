package com.jalil.harirampurnirshorgosongo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        // Find the "Add Member" button by its ID
        Button addMemberButton = findViewById(R.id.add_member_button);

        // Set an OnClickListener for the "Add Member" button
        addMemberButton.setOnClickListener(view -> {
            // Create an intent to open the AddMemberActivity
            Intent intent = new Intent(MainActivity2.this, activity_add_member.class);

            // Start the AddMemberActivity
            startActivity(intent);
        });

        // Find the "View Members" button by its ID
        Button viewMembersButton = findViewById(R.id.view_members_button);

        // Set an OnClickListener for the "View Members" button
        viewMembersButton.setOnClickListener(view -> {
            // Create an intent to open the ViewMembeersActivity2
            Intent intent = new Intent(MainActivity2.this, ViewMembeersActivity2.class);

            // Start the ViewMembeersActivity2
            startActivity(intent);
        });
    }
}
