package com.jalil.harirampurnirshorgosongo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find the "Add Member" button by its ID
        Button addMemberButton = findViewById(R.id.add_member_button);

        // Set an OnClickListener for the "Add Member" button
        addMemberButton.setOnClickListener(view -> {
            // Create an intent to open the AddMemberActivity
            Intent intent = new Intent(MainActivity.this, activity_add_member.class);

            // Start the AddMemberActivity
            startActivity(intent);
        });

        // Find the "View Members" button by its ID
        Button viewMembersButton = findViewById(R.id.view_member_button);

        // Set an OnClickListener for the "View Members" button
        viewMembersButton.setOnClickListener(view -> {
            // Create an intent to open the ViewMembersActivity (replace with the actual activity name)
            Intent intent = new Intent(MainActivity.this, ViewMembersActivity.class);

            // Start the ViewMembersActivity
            startActivity(intent);
        });

        Button searchMembersButton = findViewById(R.id.search_member_button);

        searchMembersButton.setOnClickListener(view -> {
            // Create an intent to open the ViewMembersActivity (replace with the actual activity name)
            Intent intent = new Intent(MainActivity.this, SearchData.class);

            // Start the ViewMembersActivity
            startActivity(intent);
        });

        Button pendingApprovalButton = findViewById(R.id.pending_approval_button);

        // Set an OnClickListener for the "Pending Approval" button
        pendingApprovalButton.setOnClickListener(view -> {
            // Create an intent to open the ClientRequestActivity (replace with the actual activity name)
            Intent intent = new Intent(MainActivity.this, client_request.class);

            // Start the ClientRequestActivity
            startActivity(intent);
        });



    }
}